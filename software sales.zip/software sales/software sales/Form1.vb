﻿Public Class Form1

    'jefffrey hagan 
    'vb for business
    'software sales

    'constants stored publicly
    Const YEARLY_PRICE As Integer = 5000
    Const ONE_TIME_PURCHASE As Integer = 20000
    Const lvl_3 As Integer = 3500
    Const on_site As Integer = 2000
    Const cloud_backup As Integer = 300

    'hold yearly and one time constant and converted to currency string 
    Dim intHold1 As Integer
    Dim intHold2 As Integer

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click


        If radYealy.Checked = True Then

            intHold1 = YEARLY_PRICE
            lblCostSoftware.Text = intHold1.ToString("c")

            'intSum will hold total sum for check box and is added to sum if checkbox is true
            Dim intSum As Integer
            If chkLvl3.Checked = True Then
                intSum += lvl_3
            End If
            If chkOnSite.Checked = True Then
                intSum += on_site
            End If
            If chkCloud.Checked = True Then
                intSum += cloud_backup
            End If

            intHold2 = intSum
            lblCostOfOption.Text = intHold2.ToString("c")


        ElseIf radOneTime.Checked = True Then

            intHold1 = ONE_TIME_PURCHASE
            lblCostSoftware.Text = intHold1.ToString("c")

            'intSum will hold total sum for check box and is added to sum if checkbox is true
            Dim intSum As Integer
            If chkLvl3.Checked = True Then
                intSum += lvl_3
            End If
            If chkOnSite.Checked = True Then
                intSum += on_site
            End If
            If chkCloud.Checked = True Then
                intSum += cloud_backup
            End If

            intHold2 = intSum
            lblCostOfOption.Text = intHold2.ToString("c")

        ElseIf radOneTime.Checked = False Or radYealy.Checked = False Then
            MsgBox("please click on a licensing Option ", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        chkCloud.Checked = False
        chkLvl3.Checked = False
        chkOnSite.Checked = False
        radOneTime.Checked = False
        radYealy.Checked = False
        lblCostOfOption.Text = ""
        lblCostSoftware.Text = ""
    End Sub
End Class
