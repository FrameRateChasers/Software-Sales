﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblCostSoftware = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblCostOfOption = New System.Windows.Forms.Label()
        Me.radYealy = New System.Windows.Forms.RadioButton()
        Me.radOneTime = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkCloud = New System.Windows.Forms.CheckBox()
        Me.chkOnSite = New System.Windows.Forms.CheckBox()
        Me.chkLvl3 = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(37, 265)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(103, 46)
        Me.btnCalc.TabIndex = 0
        Me.btnCalc.Text = "CALCULATE"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(173, 265)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(103, 46)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(305, 265)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(103, 46)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(51, 157)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(330, 84)
        Me.Button4.TabIndex = 3
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(70, 173)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "COST OF SOFTWARE LICENSING:"
        '
        'lblCostSoftware
        '
        Me.lblCostSoftware.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostSoftware.Location = New System.Drawing.Point(284, 163)
        Me.lblCostSoftware.Name = "lblCostSoftware"
        Me.lblCostSoftware.Size = New System.Drawing.Size(71, 23)
        Me.lblCostSoftware.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(70, 205)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(173, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "COST OF OPTIONAL FEATURES:"
        '
        'lblCostOfOption
        '
        Me.lblCostOfOption.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostOfOption.Location = New System.Drawing.Point(284, 195)
        Me.lblCostOfOption.Name = "lblCostOfOption"
        Me.lblCostOfOption.Size = New System.Drawing.Size(71, 23)
        Me.lblCostOfOption.TabIndex = 9
        '
        'radYealy
        '
        Me.radYealy.AutoSize = True
        Me.radYealy.Location = New System.Drawing.Point(13, 23)
        Me.radYealy.Name = "radYealy"
        Me.radYealy.Size = New System.Drawing.Size(115, 17)
        Me.radYealy.TabIndex = 10
        Me.radYealy.TabStop = True
        Me.radYealy.Text = "YEARLY LICENSE"
        Me.radYealy.UseVisualStyleBackColor = True
        '
        'radOneTime
        '
        Me.radOneTime.AutoSize = True
        Me.radOneTime.Location = New System.Drawing.Point(13, 68)
        Me.radOneTime.Name = "radOneTime"
        Me.radOneTime.Size = New System.Drawing.Size(139, 17)
        Me.radOneTime.TabIndex = 11
        Me.radOneTime.TabStop = True
        Me.radOneTime.Text = "ONE TIME PURCHASE"
        Me.radOneTime.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radOneTime)
        Me.GroupBox1.Controls.Add(Me.radYealy)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "LICENSING OPTIONS"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkCloud)
        Me.GroupBox2.Controls.Add(Me.chkOnSite)
        Me.GroupBox2.Controls.Add(Me.chkLvl3)
        Me.GroupBox2.Location = New System.Drawing.Point(242, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(217, 100)
        Me.GroupBox2.TabIndex = 13
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "OPTIONAL FEATURES(YEARLY)"
        '
        'chkCloud
        '
        Me.chkCloud.AutoSize = True
        Me.chkCloud.Location = New System.Drawing.Point(15, 69)
        Me.chkCloud.Name = "chkCloud"
        Me.chkCloud.Size = New System.Drawing.Size(112, 17)
        Me.chkCloud.TabIndex = 16
        Me.chkCloud.Text = "CLOUD BACK-UP"
        Me.chkCloud.UseVisualStyleBackColor = True
        '
        'chkOnSite
        '
        Me.chkOnSite.AutoSize = True
        Me.chkOnSite.Location = New System.Drawing.Point(15, 46)
        Me.chkOnSite.Name = "chkOnSite"
        Me.chkOnSite.Size = New System.Drawing.Size(124, 17)
        Me.chkOnSite.TabIndex = 15
        Me.chkOnSite.Text = "ON SITE TRAINING"
        Me.chkOnSite.UseVisualStyleBackColor = True
        '
        'chkLvl3
        '
        Me.chkLvl3.AutoSize = True
        Me.chkLvl3.Location = New System.Drawing.Point(15, 23)
        Me.chkLvl3.Name = "chkLvl3"
        Me.chkLvl3.Size = New System.Drawing.Size(186, 17)
        Me.chkLvl3.TabIndex = 14
        Me.chkLvl3.Text = "LEVEL 3 TECHNICAL SUPPORT"
        Me.chkLvl3.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(471, 333)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lblCostOfOption)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblCostSoftware)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Software Sales"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblCostSoftware As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblCostOfOption As Label
    Friend WithEvents radYealy As RadioButton
    Friend WithEvents radOneTime As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkLvl3 As CheckBox
    Friend WithEvents chkCloud As CheckBox
    Friend WithEvents chkOnSite As CheckBox
End Class
